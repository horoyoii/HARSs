package com.example.myapplication.Fragments;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;


import com.example.myapplication.App;
import com.example.myapplication.DetailActivity;
import com.example.myapplication.R;
import com.example.myapplication.Word;
import com.opencsv.CSVReader;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;


// In this case, the fragment displays simple text based on the page
public class SearchFragment extends Fragment implements View.OnClickListener {

    private static final String TAG = SearchFragment.class.getName();
    private View view;

    private EditText edit_serach_keyword;
    private Button btn_search, btn_bookmark;

    private ProgressDialog mProgressDialog;
    private BackgroundThread mBackThread;

    private TextView txt_name, txt_type, txt_content;
    private View txt_divider;
    ArrayList<Word> Words = new ArrayList<>();
    private Word curWord;

    private ListView listView;
    private ArrayList<String> search_itemList;
    ArrayAdapter arrayAdapter;

    int start_idx;

    @Override
    public void onAttach(Context context) {
        Log.d(TAG, "onAttach()");
        super.onAttach(context);
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        Log.d(TAG, "onCreate()");
        super.onCreate(savedInstanceState);

        search_itemList = new ArrayList<>();



    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        Log.d(TAG, "onCreateView()");
        view = inflater.inflate(R.layout.fragment_search, container, false);
        edit_serach_keyword = view.findViewById(R.id.edit_search);
        btn_search = view.findViewById(R.id.btn_search);
        btn_search.setOnClickListener(this);
        txt_name = view.findViewById(R.id.txt_name);

        txt_divider = view.findViewById(R.id.txt_divider);
        txt_divider.setVisibility(View.INVISIBLE);



        listView = view.findViewById(R.id.listview_search);
        arrayAdapter = new ArrayAdapter(getActivity(), R.layout.search_item, R.id.search_name_in_item, search_itemList);
        listView.setAdapter(arrayAdapter);


        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                //Toast.makeText(getContext(), adapterView.getItemAtPosition(i).toString(), Toast.LENGTH_LONG).show();
                Intent intent = new Intent(getActivity(), DetailActivity.class);
                intent.putExtra("name", Words.get(start_idx+i).getName());
                intent.putExtra("type", Words.get(start_idx+i).getType());
                intent.putExtra("content", Words.get(start_idx+i).getContent());
                intent.putExtra("position", start_idx+i);
                intent.putExtra("from", "search");
                startActivity(intent);
            }
        });


        mProgressDialog = ProgressDialog.show(
                getContext(), "DB 업데이트 중",
                "잠시만 기다려주세요..");

        mBackThread = new BackgroundThread();
        mBackThread.setRunning(true);
        mBackThread.start();




        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        Log.d(TAG, "onActivityCreated()");
        super.onActivityCreated(savedInstanceState);


        if (savedInstanceState != null) {
            // Restore last state for checked position.

        }

    }


    public int FindTheResult(){
        String keyword = edit_serach_keyword.getText().toString();
        if(keyword.charAt(0) == 'a'){
            keyword = "A"+keyword.substring(1);
        }
        //Binary Search
        int left = 0;
        int right = Words.size()-1;
        int mid, res;
        while(left <= right){
            mid = (left + right) /2;
            Log.d("HHH", "mid : "+String.valueOf(mid));
            res = Words.get(mid).getName().compareTo(keyword);
            Log.d("HHH", "res : "+String.valueOf(res));
            if( res ==0){



                txt_divider.setVisibility(View.VISIBLE);



                // 최대 다섯개
                findTheFive(mid, keyword);


                // 히스토리 추가 ====================================================================================
                ((App)(getActivity().getApplication())).getHistory_itemList().add(Words.get(mid).getName());
                ((App)(getActivity().getApplication())).getArrayAdapter().notifyDataSetChanged();

                return mid;
            }else if(res > 0)
                right = mid-1;
            else
                left = mid+1;

        }
        return -1;


    }

    public void findTheFive(int curIdx, String keyword){
        // Words.get(mid).getName()
        search_itemList.clear();

        while(Words.get(curIdx-1).getName().compareTo(keyword) == 0){
            curIdx--;
        }
        start_idx = curIdx;

        int len = keyword.length();
        int i;
        int cnt =0;

        for(i =0;i<5;i++){
            if((keyword.length() <= Words.get(curIdx+i).getName().length()) && keyword.compareTo(Words.get(curIdx+i).getName().substring(0, len)) == 0){
                cnt++;
                Log.d("HHH", Words.get(curIdx+i).getContent());
                search_itemList.add(Words.get(curIdx+i).getName());

            }else
                break;

        }
        // 일치하는 검색 결과 총 i 개
        txt_name.setText("총 "+String.valueOf(cnt)+" 개의 검색 결과...");
        arrayAdapter.notifyDataSetChanged();

    }



    public Word ParsingData(String dataStream){
        Word word = new Word();
        int idx = dataStream.indexOf('(');
        word.setName(dataStream.substring(0, idx-1));
        int idx2 = dataStream.indexOf(')');
        word.setType(dataStream.substring(idx, idx2)+")");
        word.setContent(dataStream.substring(idx2+1));
        return word;
    }

    public class BackgroundThread extends Thread {
        volatile boolean running = false;


        void setRunning(boolean b) {
            running = b;
        }

        @Override
        public void run() {
            // DB 가져오기
            int cnt =0;
            InputStreamReader is = new InputStreamReader(getResources().openRawResource(R.raw.data));
            BufferedReader reader = new BufferedReader(is);
            CSVReader read = new CSVReader(reader);
            String[] record = null;
            try {
                while ((record = read.readNext()) != null) {
                    if(record[0] != "" ) {
                        Words.add(ParsingData(record[0]));
                        cnt++;
                    }
                }
            }catch (Exception e){
                Log.d("HHH","error");
                Log.d("HHH", e.toString());
            }
            try {
                Thread.sleep(2000);
            } catch (InterruptedException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            handler.sendMessage(handler.obtainMessage());
        }
    }


    Handler handler = new Handler() {

        @Override
        public void handleMessage(Message msg) {

            mProgressDialog.dismiss();

            boolean retry = true;
            while (retry) {
                try {
                    mBackThread.join();
                    retry = false;
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }

            Toast.makeText(getContext(),
                    "완료되었습니다.", Toast.LENGTH_LONG).show();
        }
    };



    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_search:
                int res =FindTheResult();
                if(res == -1){
                    txt_name.setText("일치하는 단어가 없습니다.");
                    listView.setVisibility(View.INVISIBLE);
                    txt_divider.setVisibility(View.INVISIBLE);
                }else{
                    listView.setVisibility(View.VISIBLE);
                    txt_divider.setVisibility(View.VISIBLE);
                }

                break;
                /*
            case R.id.btn_add_bookmark:
                String keyword = edit_serach_keyword.getText().toString();

                ((App)getActivity().getApplication()).getBookmark_itemList().add(curWord);
                ((App)getActivity().getApplication()).getBookmarkAdapter().notifyDataSetChanged();



                Toast toast = Toast.makeText(getActivity(), "북마크에 추가되었습니다.", Toast.LENGTH_LONG); toast.show();
                break;
                */
        }
    }


















    @Override
    public void onDestroyView() {
        Log.d(TAG, "onDestroyView()");
        super.onDestroyView();
    }

    @Override
    public void onDestroy() {
        Log.d(TAG, "onDestroy()");
        super.onDestroy();
    }

    @Override
    public void onDetach() {
        Log.d(TAG, "onDetach()");
        super.onDetach();
    }

    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
        Log.d(TAG, "onSaveInstanceState()");
        super.onSaveInstanceState(outState);
    }



    @Override
    public void onStart() {
        Log.d(TAG, "onStart()");
        super.onStart();
    }

    @Override
    public void onStop() {
        Log.d(TAG, "onStop()");
        super.onStop();
    }

    @Override
    public void onResume() {
        Log.d(TAG, "onResume()");
        super.onResume();
    }

    @Override
    public void onPause() {
        Log.d(TAG, "onPause()");
        super.onPause();
    }
}

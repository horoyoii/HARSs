package com.example.myapplication;

import android.app.Application;
import android.widget.ArrayAdapter;

import java.util.ArrayList;

public class App extends Application {
    ArrayAdapter arrayAdapter;
    ArrayList<String> history_itemList;


    ArrayList<Word> bookmark_itemList;
    BookmarkAdapter bookmarkAdapter;

    public BookmarkAdapter getBookmarkAdapter() {
        return bookmarkAdapter;
    }

    public void setBookmarkAdapter(BookmarkAdapter bookmarkAdapter) {
        this.bookmarkAdapter = bookmarkAdapter;
    }

    public ArrayList<Word> getBookmark_itemList() {
        return bookmark_itemList;
    }

    public void setBookmark_itemList(ArrayList<Word> bookmark_itemList) {
        this.bookmark_itemList = bookmark_itemList;
    }

    public ArrayList<String> getHistory_itemList() {
        return history_itemList;
    }

    public void setHistory_itemList(ArrayList<String> history_itemList) {
        this.history_itemList = history_itemList;
    }

    public ArrayAdapter getArrayAdapter() {
        return arrayAdapter;
    }

    public void setArrayAdapter(ArrayAdapter arrayAdapter) {
        this.arrayAdapter = arrayAdapter;
    }
}

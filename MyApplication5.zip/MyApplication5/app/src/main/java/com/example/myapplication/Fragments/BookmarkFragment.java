package com.example.myapplication.Fragments;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import com.example.myapplication.App;
import com.example.myapplication.BookmarkAdapter;
import com.example.myapplication.DetailActivity;
import com.example.myapplication.R;
import com.example.myapplication.Word;

import java.util.ArrayList;
import java.util.List;


// In this case, the fragment displays simple text based on the page
public class BookmarkFragment extends Fragment implements BookmarkAdapter.ListBtnClickListener {
    private static final String TAG = BookmarkFragment.class.getName();
    private View view;

    ArrayList<Word> arrayList;
    BookmarkAdapter bookmarkAdapter;
    ListView listView;

    @Override
    public void onAttach(Context context) {
        Log.d(TAG, "onAttach()");
        super.onAttach(context);
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        Log.d(TAG, "onCreate()");
        super.onCreate(savedInstanceState);
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        Log.d(TAG, "onCreateView()");
        view = inflater.inflate(R.layout.fragment_bookmark, container, false);
        listView = view.findViewById(R.id.listview_bookmark);

        arrayList = new ArrayList<>();

        bookmarkAdapter = new BookmarkAdapter(getActivity(), R.layout.bookmark_item, arrayList, this);
        listView.setAdapter(bookmarkAdapter);

        ((App)(getActivity().getApplication())).setBookmark_itemList(arrayList);
        ((App)(getActivity().getApplication())).setBookmarkAdapter(bookmarkAdapter);


        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView parent, View v, int position, long id) {
                // TODO : item click
                Log.d("HHH","click");

            }
        }) ;

        return view;
    }

    @Override
    public void onListBtnClick(int position) {
        //Toast.makeText(this, "awef" , Toast.LENGTH_SHORT).show() ;

        Intent intent = new Intent(getActivity(), DetailActivity.class);
        intent.putExtra("name", arrayList.get(position).getName());
        intent.putExtra("type", arrayList.get(position).getType());
        intent.putExtra("content", arrayList.get(position).getContent());
        intent.putExtra("position", position);
        intent.putExtra("from", "bookmark");
        startActivity(intent);

    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        Log.d(TAG, "onActivityCreated()");
        super.onActivityCreated(savedInstanceState);


        if (savedInstanceState != null) {
            // Restore last state for checked position.

        }


    }






}

package com.example.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class DetailActivity extends AppCompatActivity {

    Button button_delete, btn_ok;
    TextView txt_name, txt_type, txt_content;
    int position;
    private Word curWord;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);


        button_delete = findViewById(R.id.de_btn_delete);
        txt_name = findViewById(R.id.de_txt_name);
        txt_type = findViewById(R.id.de_txt_type);
        txt_content = findViewById(R.id.de_txt_content);


        Intent intent = getIntent();
        String name = intent.getStringExtra("name");
        String type = intent.getStringExtra("type");
        String content = intent.getStringExtra("content");
        String from = intent.getStringExtra("from");

        curWord = new Word();
        curWord.setName(name);
        curWord.setType(type);
        curWord.setContent(content);


        txt_name.setText(name);
        txt_type.setText(type);
        txt_content.setText(content);

        position = intent.getIntExtra("position", 0);
        btn_ok = findViewById(R.id.de_btn_ok);
        btn_ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        if(from.equals("search")){
            button_delete.setText("북마크 추가");
            button_delete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    ((App)getApplication()).getBookmark_itemList().add(curWord);
                    ((App)getApplication()).getBookmarkAdapter().notifyDataSetChanged();
                    Toast.makeText(getApplicationContext(), "추가되었습니다.",Toast.LENGTH_LONG).show();

                    finish();
                }
            });
        }else{
            button_delete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    ((App)getApplication()).getBookmark_itemList().remove(position);
                    ((App)getApplication()).getBookmarkAdapter().notifyDataSetChanged();
                    Toast.makeText(getApplicationContext(), "삭제되었습니다.",Toast.LENGTH_LONG).show();

                    finish();

                }
            });
        }

    }
}

package com.example.myapplication;


import android.os.Handler;
import android.os.Message;

public class BackgroundThread extends Thread {
    Handler handler;


    @Override
    public void run() {
        super.run();

        // 데이터 메모리로 가져오는 작업



    }


}
